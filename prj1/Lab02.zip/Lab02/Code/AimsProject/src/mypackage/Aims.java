package mypackage;

public class Aims {
    public static void main(String[] args) {
        
    }
}
